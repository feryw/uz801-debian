#!/bin/sh

LED_PATH=/sys/class/leds
SIM_ENABLED=${SIM_ENABLED:-green:wan}

get_sims() {
  # shellcheck disable=SC2010
  ls /sys/class/leds | grep wan
}

disable_all_sim() {
  for sim in $(get_sims) ; do
    echo 0 > "$LED_PATH/$sim/brightness"
  done
}

enable_sim() {
  disable_all_sim
  sim="$(get_sims | grep -e "^$1")"
  echo 1 > "$LED_PATH/$sim/brightness"
}

main() {
  device_id=$(mmcli -L | awk '{print $1}')
  connection_status=$(mmcli -m ${device_id} | grep "state:" | cut -d' ' -f31 | head -n1)
  if [ -f $(echo "${connection_status}" | grep connected) ]; then
    disable_all_sim "$SIM_ENABLED"
  else
    enable_sim "$SIM_ENABLED"
  fi
}

main

